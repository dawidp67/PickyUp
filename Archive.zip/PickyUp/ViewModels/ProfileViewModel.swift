import Foundation

@MainActor
class ProfileViewModel: ObservableObject {
    @Published var attendingGames: [Game] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private let rsvpService = RSVPService.shared
    private let gameService = GameService.shared
    
    func fetchAttendingGames(userId: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let rsvps = try await rsvpService.fetchUserRSVPs(userId: userId)
            
            // Fetch game details for each RSVP
            var games: [Game] = []
            for rsvp in rsvps {
                if let game = try? await gameService.fetchGame(gameId: rsvp.gameId) {
                    games.append(game)
                }
            }
            
            // Sort by date
            attendingGames = games.sorted { $0.dateTime < $1.dateTime }
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
}
