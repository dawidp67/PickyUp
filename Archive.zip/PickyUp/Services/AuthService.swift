import Foundation
import FirebaseAuth
import FirebaseFirestore

class AuthService {
    static let shared = AuthService()
    private let auth = Auth.auth()
    private let db = Firestore.firestore()
    
    private init() {}
    
    // Get current user ID
    var currentUserId: String? {
        return auth.currentUser?.uid
    }
    
    // Sign up with email and password
    func signUp(email: String, password: String, displayName: String) async throws -> User {
        // Create auth user
        let result = try await auth.createUser(withEmail: email, password: password)
        
        // Create user document in Firestore
        let newUser = User(
            id: result.user.uid,
            email: email,
            displayName: displayName,
