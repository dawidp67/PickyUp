import Foundation
import FirebaseFirestore

class GameService {
    static let shared = GameService()
    private let db = Firestore.firestore()
    
    private init() {}
    
    // Create a new game
    func createGame(_ game: Game) async throws -> String {
        var gameData = game
        gameData.createdAt = Date()
        gameData.updatedAt = Date()
        gameData.status = .active
        
        let docRef = try db.collection("games").addDocument(from: gameData)
        return docRef.documentID
    }
    
    // Fetch all active upcoming games
    func fetchUpcomingGames() async throws -> [Game] {
        let snapshot = try await db.collection("games")
            .whereField("status", isEqualTo: GameStatus.active.rawValue)
            .whereField("dateTime", isGreaterThan: Date())
            .order(by: "dateTime")
            .getDocuments()
        
        return try snapshot.documents.compactMap { try $0.data(as: Game.self) }
    }
    
    // Fetch games created by a user
    func fetchUserCreatedGames(userId: String) async throws -> [Game] {
        let snapshot = try await db.collection("games")
            .whereField("creatorId", isEqualTo: userId)
            .order(by: "dateTime", descending: true)
            .getDocuments()
        
        return try snaps
