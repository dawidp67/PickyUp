import Foundation
import FirebaseFirestore

class RSVPService {
    static let shared = RSVPService()
    private let db = Firestore.firestore()
    
    private init() {}
    
    // Create or update RSVP
    func setRSVP(gameId: String, userId: String, userName: String, status: RSVPStatus) async throws {
        // Check if RSVP already exists
        let existingRSVPs = try await db.collection("rsvps")
            .whereField("gameId", isEqualTo: gameId)
            .whereField("userId", isEqualTo: userId)
            .getDocuments()
        
        if let existingDoc = existingRSVPs.documents.first {
            // Update existing RSVP
            try await existingDoc.reference.updateData([
                "status": status.rawValue,
                "updatedAt": Timestamp(date: Date())
            ])
        } else {
            // Create new RSVP
            let rsvp = RSVP(
                gameId: gameId,
                userId: userId,
                userName: userName,
                status: status,
                createdAt: Date(),
                updatedAt: Date()
            )
            try db.collection("rsvps").add
