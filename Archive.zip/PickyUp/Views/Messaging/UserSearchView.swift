//
//  UserSearchView.swift
//  PickyUp
//
//  Created by Dawid Pankiewicz on 11/11/25.
//

import SwiftUI

struct UserSearchView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var friendshipViewModel: FriendshipViewModel
    @EnvironmentObject var messagingViewModel: MessagingViewModel

    @State private var searchText = ""
    @State private var searchResults: [User] = []
    @State private var selectedUser: User?
    @State private var showingAlert = false
    @State private var alertMessage = ""
    @State private var viewingProfileUser: User?

    var body: some View {
        NavigationStack {
            VStack {
                // MARK: - Search Bar
                TextField("Search users...", text: $searchText)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                    .onSubmit {
                        Task { await searchUsers() }
                    }

                // MARK: - Search Results
                List(searchResults) { user in
                    Button {
                        selectedUser = user
                    } label: {
                        HStack {
                            Circle()
                                .fill(Color.blue.opacity(0.2))
                                .frame(width: 40, height: 40)
                                .overlay(
                                    Text(user.initials)
                                        .font(.headline)
                                        .foregroundStyle(.blue)
                                )

                            VStack(alignment: .leading) {
                                Text(user.displayName)
                                    .font(.headline)
                                Text(user.email)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
                .listStyle(.plain)
            }
            .navigationTitle("Find People")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Search") {
                        Task { await searchUsers() }
                    }
                }
            }

            // MARK: - Action Sheet for Selected User
            .confirmationDialog(
                selectedUser?.displayName ?? "",
                isPresented: Binding(
                    get: { selectedUser != nil },
                    set: { if !$0 { selectedUser = nil } }
                ),
                titleVisibility: .visible
            ) {
                if let user = selectedUser {
                    Button("Add Friend") {
                        Task {
                            await addFriend(user)
                        }
                    }
                    Button("Message") {
                        Task {
                            await startConversation(with: user)
                        }
                    }
                    Button("View Profile") {
                        viewingProfileUser = user
                        selectedUser = nil
                    }
                    Button("Cancel", role: .cancel) { selectedUser = nil }
                }
            }

            // MARK: - View Profile Sheet
            .sheet(item: $viewingProfileUser) { user in
                UserProfileView(user: user)
                    .environmentObject(authViewModel)
                    .environmentObject(friendshipViewModel)
                    .environmentObject(messagingViewModel)
            }

            // MARK: - Alert
            .alert("Notice", isPresented: $showingAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(alertMessage)
            }
        }
    }

    // MARK: - Search Logic
    private func searchUsers() async {
        guard !searchText.isEmpty else { return }
        do {
            let results = try await AuthService.shared.searchUsers(keyword: searchText)
            await MainActor.run {
                self.searchResults = results.filter { $0.id != authViewModel.currentUser?.id }
            }
        } catch {
            await MainActor.run {
                self.alertMessage = "Failed to search users: \(error.localizedDescription)"
                self.showingAlert = true
            }
        }
    }

    // MARK: - Add Friend
    private func addFriend(_ user: User) async {
        guard let currentUserId = authViewModel.currentUser?.id,
              let targetUserId = user.id else { return }
        
        do {
            try await FriendshipService.shared.sendFriendRequest(from: currentUserId, to: targetUserId)
            await MainActor.run {
                alertMessage = "Friend request sent to \(user.displayName)."
                showingAlert = true
            }
        } catch {
            await MainActor.run {
                alertMessage = "Failed to send friend request: \(error.localizedDescription)"
                showingAlert = true
            }
        }
    }

    // MARK: - Start Conversation
    private func startConversation(with user: User) async {
        guard let currentUser = authViewModel.currentUser,
              let currentUserId = currentUser.id else { return }
        
        let conversation = await messagingViewModel.startDMConversation(
            withUser: user,
            currentUserId: currentUserId,
            currentUserName: currentUser.displayName
        )
        
        await MainActor.run {
            if conversation != nil {
                alertMessage = "Chat started with \(user.displayName)."
            } else {
                alertMessage = "Failed to start chat."
            }
            showingAlert = true
        }
    }
}

// MARK: - Preview
#Preview {
    UserSearchView()
        .environmentObject(AuthViewModel())
        .environmentObject(FriendshipViewModel())
        .environmentObject(MessagingViewModel())
}
