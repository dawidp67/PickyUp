12.4.0 - [GoogleUtilities/AppDelegateSwizzler][I-SWZ001014] App Delegate does not conform to UIApplicationDelegate protocol.
🔥 Firebase configured successfully
🗺️ LocationService initialized
🗺️ Current authorization status: 3
✅ Location authorized - starting updates
🔄 Authorization changed to: 3
🗺️ Current authorization status: 3
✅ Location authorized - starting updates
📍 Location updated: 42.0297619340397, -87.92617877658925
📍 Location updated: 42.0297619340397, -87.92617877658925
📍 Location updated: 42.02970265848787, -87.92628185521055
📍 Location updated: 42.0297619340397, -87.92617877658925
12.4.0 - [FirebaseFirestore][I-FST000002] Attempting to initialize or set a @DocumentID property with a non-nil value: "l0OioQm4dKQvbNEc2ov9rBGaGIl2". The document ID is managed by Firestore and any initialized or set value will be ignored. The ID is automatically set when reading from Firestore.
onChange(of: Optional<Double>) action tried to update multiple times per frame.
📍 Location updated: 42.02970208757276, -87.92628536753658
Failed to locate resource named "default.csv"
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 0;
}
CAMetalLayer ignoring invalid setDrawableSize width=0.000000 height=0.000000
Publishing changes from within view updates is not allowed, this will cause undefined behavior.
Publishing changes from within view updates is not allowed, this will cause undefined behavior.
<0x1059f2440> Gesture: System gesture gate timed out.
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 1;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 0;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 1;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
CAMetalLayer ignoring invalid setDrawableSize width=0.000000 height=0.000000
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 0;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 1;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 0;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 1;
}
📍 Location updated: 42.0297619340397, -87.92617877658925
Publishing changes from within view updates is not allowed, this will cause undefined behavior.
Called -[UIContextMenuInteraction updateVisibleMenuWithBlock:] while no context menu is visible. This won't do anything.
Called -[UIContextMenuInteraction updateVisibleMenuWithBlock:] while no context menu is visible. This won't do anything.
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 0;
}
CAMetalLayer ignoring invalid setDrawableSize width=0.000000 height=0.000000
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 1;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 0;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 1;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 0;
}
CAMetalLayer ignoring invalid setDrawableSize width=0.000000 height=0.000000
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 1;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 0;
}
Connection error: Error Domain=NSCocoaErrorDomain Code=4099 "The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction." UserInfo={NSDebugDescription=The connection to service named com.apple.PerfPowerTelemetryClientRegistrationService was invalidated: Connection init failed at lookup with error 159 - Sandbox restriction.}
(+[PPSClientDonation isRegisteredSubsystem:category:]) Permission denied: Maps / SpringfieldUsage
(+[PPSClientDonation sendEventWithIdentifier:payload:]) Invalid inputs: payload={
    isSPR = 1;
}
Called -[UIContextMenuInteraction updateVisibleMenuWithBlock:] while no context menu is visible. This won't do anything.
UIKeyboardLayoutStar implements focusItemsInRect: - caching for linear focus movement is limited as long as this view is on screen.
Result accumulator timeout: 0.250000, exceeded.
Attempted to update accumulator from source type: 0, after completion has already been called for token:[DF65FDA4]. This is an error and will be ignored.
containerToPush is nil, will not push anything to candidate receiver for request token: DF65FDA4
Attempted to update accumulator from source type: 0, after completion has already been called for token:[DF65FDA4]. This is an error and will be ignored.
containerToPush is nil, will not push anything to candidate receiver for request token: DF65FDA4
<0x1059f2440> Gesture: System gesture gate timed out.
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
Reporter disconnected. { function=sendMessage, reporterID=59365037965314 }
📍 Location updated: 42.02970490140892, -87.92627355528559
Publishing changes from within view updates is not allowed, this will cause undefined behavior.
📍 Location updated: 42.02968624930266, -87.92621766149026
Publishing changes from within view updates is not allowed, this will cause undefined behavior.
